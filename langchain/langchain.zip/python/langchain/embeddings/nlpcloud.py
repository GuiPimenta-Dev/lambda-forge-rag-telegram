from langchain_community.embeddings.nlpcloud import NLPCloudEmbeddings

__all__ = ["NLPCloudEmbeddings"]
