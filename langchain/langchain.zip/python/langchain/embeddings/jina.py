from langchain_community.embeddings.jina import JinaEmbeddings

__all__ = ["JinaEmbeddings"]
