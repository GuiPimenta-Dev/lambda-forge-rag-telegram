from langchain_community.embeddings.ernie import ErnieEmbeddings

__all__ = ["ErnieEmbeddings"]
