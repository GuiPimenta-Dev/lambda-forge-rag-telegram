from langchain_community.embeddings.clarifai import ClarifaiEmbeddings

__all__ = ["ClarifaiEmbeddings"]
