from langchain_community.embeddings.embaas import (
    EmbaasEmbeddings,
)

__all__ = [
    "EmbaasEmbeddings",
]
