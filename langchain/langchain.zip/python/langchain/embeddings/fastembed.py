from langchain_community.embeddings.fastembed import FastEmbedEmbeddings

__all__ = ["FastEmbedEmbeddings"]
