from langchain_community.embeddings.awa import AwaEmbeddings

__all__ = ["AwaEmbeddings"]
