from langchain_community.embeddings.azure_openai import AzureOpenAIEmbeddings

__all__ = ["AzureOpenAIEmbeddings"]
