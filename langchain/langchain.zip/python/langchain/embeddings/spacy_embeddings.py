from langchain_community.embeddings.spacy_embeddings import SpacyEmbeddings

__all__ = ["SpacyEmbeddings"]
