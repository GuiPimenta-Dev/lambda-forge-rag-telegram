from langchain_community.embeddings.huggingface_hub import (
    HuggingFaceHubEmbeddings,
)

__all__ = ["HuggingFaceHubEmbeddings"]
