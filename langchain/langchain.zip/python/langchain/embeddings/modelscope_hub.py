from langchain_community.embeddings.modelscope_hub import ModelScopeEmbeddings

__all__ = ["ModelScopeEmbeddings"]
