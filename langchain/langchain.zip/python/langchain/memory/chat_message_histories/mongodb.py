from langchain_community.chat_message_histories.mongodb import (
    MongoDBChatMessageHistory,
)

__all__ = ["MongoDBChatMessageHistory"]
