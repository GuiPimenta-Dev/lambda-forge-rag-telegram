from langchain_community.tools.eleven_labs.models import ElevenLabsModel

__all__ = ["ElevenLabsModel"]
