from langchain_community.tools.azure_cognitive_services.form_recognizer import (
    AzureCogsFormRecognizerTool,
)

__all__ = ["AzureCogsFormRecognizerTool"]
