from langchain_community.tools.azure_cognitive_services.image_analysis import (
    AzureCogsImageAnalysisTool,
)

__all__ = ["AzureCogsImageAnalysisTool"]
