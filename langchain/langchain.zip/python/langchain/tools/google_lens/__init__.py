"""Google Lens API Toolkit."""

from langchain_community.tools.google_lens.tool import GoogleLensQueryRun

__all__ = ["GoogleLensQueryRun"]
