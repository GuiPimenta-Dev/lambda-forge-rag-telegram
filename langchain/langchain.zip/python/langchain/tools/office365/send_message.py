from langchain_community.tools.office365.send_message import (
    O365SendMessage,
    SendMessageSchema,
)

__all__ = ["SendMessageSchema", "O365SendMessage"]
