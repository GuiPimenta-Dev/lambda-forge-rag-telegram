"""Wikipedia API toolkit."""
