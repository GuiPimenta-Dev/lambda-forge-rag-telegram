from langchain_community.tools.wikipedia.tool import WikipediaQueryRun

__all__ = ["WikipediaQueryRun"]
