"""Tool to generate an image."""

from langchain_community.tools.steamship_image_generation.tool import (
    SteamshipImageGenerationTool,
)

__all__ = ["SteamshipImageGenerationTool"]
