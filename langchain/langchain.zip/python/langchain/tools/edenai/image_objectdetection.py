from langchain_community.tools.edenai.image_objectdetection import (
    EdenAiObjectDetectionTool,
)

__all__ = ["EdenAiObjectDetectionTool"]
